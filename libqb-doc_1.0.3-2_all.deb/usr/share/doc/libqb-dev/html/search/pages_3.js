var searchData=
[
  ['handle_20database',['Handle Database',['../qb_hdb_overview.html',1,'index']]]
];
