var searchData=
[
  ['qb_5fver',['qb_ver',['../qbutil_8h.html#a278ef1d11385d4f752e6bf9a1327216b',1,'qbutil.h']]],
  ['qb_5fver_5fstr',['qb_ver_str',['../qbutil_8h.html#a48479fa5498ac50126a9bbbd66400e35',1,'qbutil.h']]]
];
