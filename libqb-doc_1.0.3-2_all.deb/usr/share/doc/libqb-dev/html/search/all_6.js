var searchData=
[
  ['handle_5fcount',['handle_count',['../structqb__hdb.html#af1b10904b26854e8d7fa2500b0783e1f',1,'qb_hdb']]],
  ['handles',['handles',['../structqb__hdb.html#abcc15bba6219ca87512088583d0a6d98',1,'qb_hdb']]],
  ['hz',['HZ',['../qbdefs_8h.html#a8489802eaedf42fdb5f2ce1708eaffa2',1,'qbdefs.h']]],
  ['handle_20database',['Handle Database',['../qb_hdb_overview.html',1,'index']]]
];
