var searchData=
[
  ['hz',['HZ',['../qbdefs_8h.html#a8489802eaedf42fdb5f2ce1708eaffa2',1,'qbdefs.h']]]
];
