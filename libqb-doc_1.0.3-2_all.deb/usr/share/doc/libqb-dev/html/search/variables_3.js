var searchData=
[
  ['destructor',['destructor',['../structqb__hdb.html#a857a6b3e21b4fcb5d9b497b1de889849',1,'qb_hdb']]],
  ['dispatch_5fadd',['dispatch_add',['../structqb__ipcs__poll__handlers.html#a3c0decaeb26b23c0437cfabf1ed80382',1,'qb_ipcs_poll_handlers']]],
  ['dispatch_5fdel',['dispatch_del',['../structqb__ipcs__poll__handlers.html#a402818d5d63b105a2635552e51a69dae',1,'qb_ipcs_poll_handlers']]],
  ['dispatch_5fmod',['dispatch_mod',['../structqb__ipcs__poll__handlers.html#a5168fac13c7d3eec43d0befd7abd7174',1,'qb_ipcs_poll_handlers']]]
];
