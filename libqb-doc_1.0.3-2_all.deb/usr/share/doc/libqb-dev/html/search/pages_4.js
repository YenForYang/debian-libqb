var searchData=
[
  ['ipc_20overview',['IPC Overview',['../qb_ipc_overview.html',1,'index']]]
];
